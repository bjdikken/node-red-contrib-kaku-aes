# node-red-kaku-aes
Node-RED nodes using CryptoJS to encrypt and decrypt kaku messages

# Install
#npm install node-red-kaku-aes
use package uploader from node-red settings

# Sample Flows
not yet available 

# CryptoJS 
> JavaScript library of crypto standards.

Encrypt and Decrypt Nodes:
* crypto-js/aes